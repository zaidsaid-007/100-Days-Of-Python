#-------------------------------------------------------------------------------
# Final Project
# Student Name: 
# Submission Date: 99/99/9999
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines as set forth by the
# instructor and the class syllabus.
#-------------------------------------------------------------------------------
# References: 
#-------------------------------------------------------------------------------
# Notes to grader: 
#-------------------------------------------------------------------------------
# Your source code below
#-------------------------------------------------------------------------------

import csv

#your code here
#define a class Cart - a subclass of list class
#define a subtotal function
#Returns subtotal from a Cart list object
    
    

class App(object):
    '''App class defines an app item
    available in store. App object saved in
    category_dict per category
    and rating_dict per rating and price_dict per price '''
    category_dict = {}
    rating_dict = {}
    price_dict = {}

    def __init__(self, ID, name, developer, description, price, rating, review_count, category):
        '''Initialization method'''
        self.__id = ID
        #your code here
        #initialize name, developer, description, price, rating,
        #review_count, category as private attribute
        #populate dict by category - key = category and values = list of app objects
        if self.__category in App.category_dict.keys():
            #your code here
            #append object to current category
        else:
            #your code here

        #populate rating_dict and price_dict
        #rating_dict key = rating value as whole number
        # for example an app of 4.9 rating will be saved under key 4 and values = list of objects for
        #that rating
        #price_dict will be similar as rating except key will be price,
        #all the apps between 1.00$-1.99 will be under key 1.00$

            
    #your code here
    #define get methods
    #to return all private attributes


#process file
filename = 'Top50ShopifyApps.csv'
with open(filename) as fin:
    #use csv reader to read the file info
    #slip the header
    #itereate over each line
    #separate the ID, name, developer, description, price, rating, review_count, category
    #create an object
        


'''Testing code to check object creating Items
Uncomment to test and then
Comment out when done'''
'''
for k,v in App.category_dict.items(): #v is a list of all objects
    print(k, [(obj.get_name(), obj.get_rating()) for obj in v ])
print('++++++++++')

for k,v in App.rating_dict.items(): #v is a list of all objects
    print(k, [obj.get_rating() for obj in v ])
print('++++++++++')

for k,v in App.price_dict.items(): #v is a list of all objects
    print(k, [obj.get_price() for obj in v ])
print('++++++++++')
'''






          

